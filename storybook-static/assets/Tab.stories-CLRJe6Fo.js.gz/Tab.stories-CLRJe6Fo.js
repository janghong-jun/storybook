import{j as t}from"./datepicker-Dz1Ef8Gs.js";import{T as o}from"./Tab-CcTHlKzT.js";import"./react-Cl_xvQ9m.js";import"./vendors-kYdpP6Vl.js";const i={title:"UI/Tab",component:o,parameters:{layout:"centered"},argTypes:{disabled:{control:!1,description:"비활성화 여부 ",table:{type:{summary:"boolean"},defaultValue:{summary:"false"}}}},tags:["autodocs"],decorators:[n=>t.jsx("div",{style:{minWidth:"30rem",minHeight:"20rem"},children:t.jsx(n,{})})]},e={args:{items:[{label:"Home",content:"Home Content"},{label:"Profile",content:"Profile Content"},{label:"Settings",content:"Settings Content",disabled:!0}]}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {
    items: [{
      label: 'Home',
      content: 'Home Content'
    }, {
      label: 'Profile',
      content: 'Profile Content'
    }, {
      label: 'Settings',
      content: 'Settings Content',
      disabled: true
    }]
  }
}`,...e.parameters?.docs?.source}}};const m=["Default"];export{e as Default,m as __namedExportsOrder,i as default};
