import{j as s}from"./datepicker-Dz1Ef8Gs.js";import{T as r}from"./Tooltip-Cp-PtiUd.js";import"./react-Cl_xvQ9m.js";import"./vendors-kYdpP6Vl.js";const m={title:"UI/Tooltip",component:r,parameters:{layout:"centered"},tags:["autodocs"],decorators:[a=>s.jsx("div",{style:{display:"flex",position:"relative",minWidth:"100%",minHeight:"20rem",justifyContent:"center",alignContent:"center"},children:s.jsx("div",{style:{margin:"auto"},children:s.jsx(a,{})})})],argTypes:{content:{table:{type:{summary:"string | React.ReactNode"}},control:"text"},label:{control:"text"},iconClass:{control:"text"},className:{control:"text"}}},t={args:{content:"툴팁 내용입니다.",label:"툴팁 트리거"}},o={args:{content:"아이콘 툴팁 내용입니다.",label:"아이콘 툴팁 트리거",iconClass:"icon-info"}},e={args:{content:"커스텀 클래스가 적용된 툴팁 내용입니다.",label:"커스텀 클래스 툴팁 트리거",className:"custom-tooltip"}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  args: {
    content: '툴팁 내용입니다.',
    label: '툴팁 트리거'
  }
}`,...t.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    content: '아이콘 툴팁 내용입니다.',
    label: '아이콘 툴팁 트리거',
    iconClass: 'icon-info'
  }
}`,...o.parameters?.docs?.source}}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {
    content: '커스텀 클래스가 적용된 툴팁 내용입니다.',
    label: '커스텀 클래스 툴팁 트리거',
    className: 'custom-tooltip'
  }
}`,...e.parameters?.docs?.source}}};const p=["Default","IconTooltip","CustomClassTooltip"];export{e as CustomClassTooltip,t as Default,o as IconTooltip,p as __namedExportsOrder,m as default};
