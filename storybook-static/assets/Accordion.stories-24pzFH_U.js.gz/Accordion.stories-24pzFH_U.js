import{j as e}from"./datepicker-Dz1Ef8Gs.js";import"./iframe-B7ALOmHm.js";import{A as o}from"./Accordion-Df7MQ9M_.js";import"./react-Cl_xvQ9m.js";import"./vendors-kYdpP6Vl.js";import"./preload-helper-PPVm8Dsz.js";const d={title:"UI/Accordion",component:o,parameters:{layout:"centered"},tags:["autodocs"]},t={args:{items:[{title:"첫 번째 항목",content:e.jsx("p",{children:"첫 번째 내용입니다."})},{title:"두 번째 항목",content:e.jsx("p",{children:"두 번째 내용입니다."})}]}},n={args:{items:[{title:"첫 번째 항목",content:e.jsx("p",{children:"첫 번째 내용입니다."})},{title:"두 번째 항목",content:e.jsx("p",{children:"두 번째 내용입니다."})}],allowMultipleOpen:!0}},s={args:{items:[{title:"첫 번째 항목",content:e.jsx("p",{children:"첫 번째 내용입니다."})},{title:"두 번째 항목",content:e.jsx("p",{children:"두 번째 내용입니다."})}],defaultOpenIndex:0,allowMultipleOpen:!1}},r={args:{items:[{title:"첫 번째 항목",content:e.jsx("p",{children:"첫 번째 내용입니다."})},{title:"두 번째 항목",content:e.jsx("p",{children:"두 번째 내용입니다."})}],className:"custom-accordion"}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  args: {
    items: [{
      title: '첫 번째 항목',
      content: <p>첫 번째 내용입니다.</p>
    }, {
      title: '두 번째 항목',
      content: <p>두 번째 내용입니다.</p>
    }]
  }
}`,...t.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    items: [{
      title: '첫 번째 항목',
      content: <p>첫 번째 내용입니다.</p>
    }, {
      title: '두 번째 항목',
      content: <p>두 번째 내용입니다.</p>
    }],
    allowMultipleOpen: true
  }
}`,...n.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    items: [{
      title: '첫 번째 항목',
      content: <p>첫 번째 내용입니다.</p>
    }, {
      title: '두 번째 항목',
      content: <p>두 번째 내용입니다.</p>
    }],
    defaultOpenIndex: 0,
    allowMultipleOpen: false
  }
}`,...s.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    items: [{
      title: '첫 번째 항목',
      content: <p>첫 번째 내용입니다.</p>
    }, {
      title: '두 번째 항목',
      content: <p>두 번째 내용입니다.</p>
    }],
    className: 'custom-accordion'
  }
}`,...r.parameters?.docs?.source}}};const u=["Default","AllowMultiple","Index","CustomClass"];export{n as AllowMultiple,r as CustomClass,t as Default,s as Index,u as __namedExportsOrder,d as default};
